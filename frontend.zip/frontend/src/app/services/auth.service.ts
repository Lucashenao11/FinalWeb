import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://anapioficeandfire.com/api/houses';

  constructor(private http: HttpClient) {}

  getData(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  // getAllCharacters(): Observable<any[]> {
  //   for (let i = 1; i <= 10; i++){
      
  //   }
  //   return this.http.get<any[]>(this.apiUrl);
  // }
}