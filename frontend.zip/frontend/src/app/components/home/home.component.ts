import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'got-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  houses: any[] = [];
  characters: any[] = [];
  showHousesSection = true;
  selectedHouseName = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchHouses();
  }

  fetchHouses(): void {
    this.http.get<any[]>('https://anapioficeandfire.com/api/houses?pageSize=50')
      .subscribe({
        next: (houses) => {
          this.houses = houses;
        },
        error: (err) => {
          console.error('Error fetching houses:', err);
        }
      });
  }

  fetchCharacters(house: any): void {
    this.characters = [];
    this.selectedHouseName = house.name;
    const characterUrls = [
      ...house.swornMembers,
      house.currentLord || null,
      house.heir || null,
      house.founder || null
    ].filter(url => url);

    const uniqueUrls = [...new Set(characterUrls)];

    if (uniqueUrls.length === 0) {
      this.showHousesSection = false;
      return;
    }

    const requests = uniqueUrls.map(url => this.http.get<any>(url));
    forkJoin(requests).subscribe({
      next: (characters) => {
        this.characters = characters;
        this.showHousesSection = false;
      },
      error: (err) => {
        console.error('Error fetching characters:', err);
        this.showHousesSection = false;
      }
    });
  }

  showHouses(): void {
    this.showHousesSection = true;
    this.characters = [];
    this.selectedHouseName = '';
  }
}